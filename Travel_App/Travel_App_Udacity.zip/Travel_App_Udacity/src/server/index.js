const dotenv = require("dotenv");
dotenv.config();

const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const winston = require("winston");

const logger = winston.createLogger({
  level: "info",
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [new winston.transports.Console()],
});

const app = express();

app.use(express.json());
app.use(express.static("dist"));
app.use(cors());
app.use(bodyParser.json());

let tripData = [];

app.get("/trips", (req, res) => {
  res.send(tripData);
});

app.post("/trips", (req, res) => {
  const newTrip = req.body;
  tripData.push(newTrip);
  res.send(newTrip);
});

if (require.main === module) {
  // Only start the server if this file is executed directly
  const listenPort = process.env.listenPort || 3000;
  app.listen(listenPort, () => {
    console.log(`Server is running on port ${listenPort}`);
  });
}

module.exports = app;
