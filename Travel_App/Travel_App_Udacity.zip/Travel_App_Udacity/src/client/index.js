// Jubran Khoury
import "./styles/style.scss";
import "./js/app.js";

import { tripFormHandler, loadSavedTrips } from "./js/app.js";

document.addEventListener("DOMContentLoaded", () => {
  tripFormHandler();
  loadSavedTrips();
});
