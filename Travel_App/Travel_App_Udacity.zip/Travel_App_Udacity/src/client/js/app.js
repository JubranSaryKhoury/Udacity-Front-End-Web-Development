// Jubran Khoury

// In this project I used the session storage to be cleaned when the tap is closed

import { daysLeft } from "./daysLeft.js";

export function tripFormHandler() {
  const tripForm = document.getElementById("new-trip-form");
  const tripList = document.getElementById("trip-list");
  const addTripButton = document.getElementById("add-trip-button");
  const locationInfo = document.getElementById("location-info");
  const weatherInfo = document.getElementById("weather-info");

  // API's
  const geonamesAPIKey = "jubransarykhoury2002";
  const weatherbitAPIKey = "ac748aaaea6d432eb6193ce8d11a9862";
  const weatherbitURL = "https://api.weatherbit.io/v2.0/forecast/daily";
  const pixabayAPIKey = "45769649-695ef6d72b12a79a18f04b78c";

  addTripButton.addEventListener("click", () => {
    tripForm.classList.toggle("hidden");
  });

  // Submit form
  tripForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const locationInput = document.getElementById("location").value;
    const departureDateInput = document.getElementById("departure-date").value;

    // Get location data
    getLocationData(locationInput)
      .then((locationData) => {
        const newTrip = {
          location: locationData.name,
          departureDate: departureDateInput,
          longitude: locationData.lng,
          latitude: locationData.lat,
          country: locationData.countryName,
        };

        // Get weather data
        getWeatherData(
          { latitude: locationData.lat, longitude: locationData.lng },
          departureDateInput
        )
          .then((weatherData) => {
            // Render the new trip in the trip list
            tripRender(newTrip, weatherData);

            // Clean form
            tripForm.reset();
            tripForm.classList.add("hidden");

            displayLocationInfo(locationData);
            displayWeatherInfo(weatherData);
          })
          .catch((error) => {
            console.error("Error: ", error);
            alert(error);
          });
      })
      .catch((error) => {
        alert("Error: " + error);
      });
  });

  function getLocationData(location) {
    const url = `http://api.geonames.org/searchJSON?q=${location}&maxRows=1&username=${geonamesAPIKey}`;

    return fetch(url)
      .then((response) => response.json())
      .then((data) => {
        if (data.geonames && data.geonames.length > 0) {
          return {
            name: data.geonames[0].name,
            lat: data.geonames[0].lat,
            lng: data.geonames[0].lng,
            countryName: data.geonames[0].countryName,
          };
        } else {
          throw new Error("Location not found");
        }
      });
  }

  function getWeatherData(coordinates, departureDate) {
    const formattedDepartureDate = new Date(departureDate)
      .toISOString()
      .slice(0, 10);
    const url = `${weatherbitURL}?lat=${coordinates.latitude}&lon=${coordinates.longitude}&key=${weatherbitAPIKey}&days=16&start_date=${formattedDepartureDate}`;

    return fetch(url).then((response) => response.json());
  }

  function fetchImage(location) {
    const encodedLocation = encodeURIComponent(location);
    const url = `https://pixabay.com/api/?key=${pixabayAPIKey}&q=${encodedLocation}&image_type=photo`;

    return fetch(url)
      .then((response) => response.json())
      .then((data) => {
        if (data.hits && data.hits.length > 0) {
          return data.hits[0].webformatURL;
        } else {
          throw new Error("Image not found");
        }
      });
  }

  function tripRender(trip, weatherData) {
    const tripCard = document.createElement("div");
    tripCard.classList.add("trip-card");

    const tripImage = document.createElement("img");
    fetchImage(trip.location)
      .then((imageUrl) => {
        tripImage.src = imageUrl;
      })
      .catch((error) => {
        console.error("Error fetching image:", error);
        tripImage.src = "https://via.placeholder.com/400x200";
      });
    tripImage.alt = `Image of ${trip.location}`;
    tripCard.appendChild(tripImage);

    const tripInfo = document.createElement("div");
    tripInfo.classList.add("trip-info");

    const tripDestination = document.createElement("h3");
    tripDestination.textContent = `My trip to: ${trip.location}`;
    tripInfo.appendChild(tripDestination);

    const tripDate = document.createElement("p");
    tripDate.textContent = `Departing: ${trip.departureDate}`;
    tripInfo.appendChild(tripDate);

    const country = document.createElement("p");
    country.classList.add("countdown");
    country.textContent = `Country: ${trip.country}`;
    tripInfo.appendChild(country);

    const tripCountdown = document.createElement("p");
    tripCountdown.classList.add("countdown");
    tripCountdown.textContent = `Countdown: ${daysLeft(
      trip.departureDate
    )} days`;
    tripInfo.appendChild(tripCountdown);

    const tripWeather = document.createElement("p");
    tripWeather.textContent = `Temperature: ${weatherData.data[0].temp} degrees, Description: ${weatherData.data[0].weather.description}`;
    tripInfo.appendChild(tripWeather);

    const buttonContainer = document.createElement("div");
    buttonContainer.classList.add("buttons");

    const saveButton = document.createElement("button");
    saveButton.classList.add("save-button");
    saveButton.textContent = "Save Trip";
    buttonContainer.appendChild(saveButton);

    const removeButton = document.createElement("button");
    removeButton.classList.add("remove-button");
    removeButton.textContent = "Remove Trip";
    buttonContainer.appendChild(removeButton);

    tripInfo.appendChild(buttonContainer);

    removeButton.addEventListener("click", () => {
      tripList.removeChild(tripCard);
      removeTrip(trip);
    });

    saveButton.addEventListener("click", () => {
      saveTrip(trip);
      saveButton.disabled = true;
      saveButton.textContent = "Trip Saved";
    });

    tripCard.appendChild(tripInfo);
    tripList.appendChild(tripCard);
  }

  function saveTrip(trip) {
    let savedTrips = JSON.parse(sessionStorage.getItem("trips")) || [];
    savedTrips.push(trip);
    sessionStorage.setItem("trips", JSON.stringify(savedTrips));
  }

  function removeTrip(trip) {
    let savedTrips = JSON.parse(sessionStorage.getItem("trips")) || [];
    savedTrips = savedTrips.filter(
      (savedTrip) =>
        savedTrip.location !== trip.location ||
        savedTrip.departureDate !== trip.departureDate
    );
    sessionStorage.setItem("trips", JSON.stringify(savedTrips));
  }

  function displayLocationInfo(locationData) {
    locationInfo.innerHTML = `
      <h3>Location: ${locationData.name}</h3> 
      <h3>Longitude: ${locationData.lng}</h3> 
      <h3>Latitude: ${locationData.lat}</h3> 
      <h3>Country: ${locationData.countryName}</h3> 
    `;
  }

  function displayWeatherInfo(weatherData) {
    weatherInfo.innerHTML = `
      <p><strong>Temperature:</strong> ${weatherData.data[0].temp} degrees</p>
      <p><strong>Description:</strong> ${weatherData.data[0].weather.description}</p>
    `;
  }
}

export function loadSavedTrips() {
  const savedTrips = JSON.parse(sessionStorage.getItem("trips")) || [];
  savedTrips.forEach((trip) => {
    getWeatherData(
      { latitude: trip.latitude, longitude: trip.longitude },
      trip.departureDate
    )
      .then((weatherData) => {
        tripRender(trip, weatherData);
      })
      .catch((error) => {
        console.error("Error fetching weather data for saved trip:", error);
      });
  });
}
