export function daysLeft(date) {
  const today = new Date();
  const futureDate = new Date(date);
  return Math.ceil((futureDate - today) / (1000 * 60 * 60 * 24));
}
