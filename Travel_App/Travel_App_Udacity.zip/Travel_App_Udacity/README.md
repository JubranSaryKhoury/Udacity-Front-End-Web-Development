# Travel app - Plan Your Travel

# How to run it

1. npm install (in order to install dependencies)
2. npm run build
3. npm run start

# Versions

npm --> 10.8.2
node --> v20.15.1

please check the attached two images (attached with the project .zip file)
